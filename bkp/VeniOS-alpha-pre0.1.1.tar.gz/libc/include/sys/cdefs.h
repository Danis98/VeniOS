#ifndef _SYS_CDEFS_H
#define _SYS_CDEFS_H 1

#define __venios_libc 1

#endif
