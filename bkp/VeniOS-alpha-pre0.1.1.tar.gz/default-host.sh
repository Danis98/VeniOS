#!/bin/sh
echo i686-elf
