/***********************************************************
 * VeniOS Alpha kernel
 * Made by Venio
 * Copyright (c) 2014 Weird Lion Studios 
***********************************************************/

#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include <kernel/vga.h>
#include <kernel/tty.h>

//Are we targeting the host OS?
#if defined(__linux__)
#error "Not using a cross compiler! There will be trouble!"
#endif

void kernel_early(void){
	terminal_initialize(COLOR_LIGHT_GREY,COLOR_BLACK);
}

void kernel_main(void){
	printf("VeniOS Alpha by Venio\nHello World!\n");
	terminal_setcolor(COLOR_RED,COLOR_BLACK);
	printf("Copyright (c) 2014 Weird Lion Studios\n\n");
	terminal_setcolor(COLOR_BLACK,COLOR_LIGHT_CYAN);
	printf("Kernel version:          0.1.0\n"
		"Using custom freestanding libc\n");
	terminal_setcolor(COLOR_LIGHT_GREY,COLOR_BLACK);
}
