#include <string.h>

size_t strlen(const char* string){
	size_t cur_size=0;
	while(string[cur_size])
		cur_size++;
	return cur_size;
}
